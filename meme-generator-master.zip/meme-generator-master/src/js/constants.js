export const ACCEPTED_MIME_TYPES = [
  'image/jpg',
  'image/jpeg',
  'image/png',
  'image/apng',
  'image/gif',
  'image/webp',
  'image/avif'
];
export const MAX_SHADOW_BLUR_SIZE = 20;
export const MAX_STROKE_WIDTH = 20;
export const MAX_ROTATE = 360;
