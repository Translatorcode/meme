export const isSolidColorSelected = selectedImage => {
  return typeof selectedImage === 'string';
};
